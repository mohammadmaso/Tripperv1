from django.apps import AppConfig


class WikiConfig(AppConfig):
    name = 'wiki'
